Yifan's Kindle Jailbreak 0.4

This jailbreak will allow you to install custom hack updates along with official Kindle updates from Amazon.

To install, just copy the .bin corresponding to your Kindle model onto the root of your Kindle USB drive. Then, go to Settings, press Menu, and choose Update Your Kindle.

Update prefix -> Kindle model
k3w -> Kindle 3 Wifi
k3gb -> Kindle 3 Wifi + 3G (Non-US/Canada model)
k3g -> Kindle 3 Wifi + 3G (US/Canada model)
dxi -> Kindle DX White (International)
dxg -> Kindle DX Graphite
dx -> Kindle DX White (US only 3G)
k2i -> Kindle 2 (International)
k2 -> Kindle 2 (US only 3G)

If you used an older version of this jailbreak, you can safely install onto of it. The installer uninstalls all previous versions.
If you used NiLuJe's jailbreak. You do NOT need this, and the install will fail. You can use this once you uninstall NiLuJe's jailbreak if you wish.

Parts of this jailbreak are based on the ideas of NiLuJe. Thanks to him for such an easy to use jailbreak.
~Jailbreak by Yifan Lu (http://yifan.lu/)~
